package userListPackage;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebsiteDriver {

	public static Map<String, String> page_Objects = new HashMap<String, String> ();
	public static WebDriver myDriver;

	public WebElement getElement(String str) throws Exception {
		WebElement element=null;
		String elXpath="";
		String type="";
		
		try {
			String desc = page_Objects.get(str);
			String[] a = desc.split("\\|");
			WebDriverWait wait = new WebDriverWait(myDriver, 120);

			elXpath = a[1];
			type = a[0];
			
			switch (a[0]) {
			case "ID":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(a[1])));
				element = myDriver.findElement(By.id(a[1]));break;
			case "XPATH":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(a[1])));
				 element=myDriver.findElement(By.xpath(a[1]));
			default:
				System.out.println("Cannot return object!" + str);
				break;
			}
		return element;
		} catch (Exception e) {
			System.out.println("Error in WebsiteDriver class: "+e.getMessage());
		}
		return element;

	}
}
