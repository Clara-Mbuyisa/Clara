package userListPackage;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class NewTest {
	   public String baseUrl = "https://www.ilabquality.com/";
	   String driverPath = "C:\\Automation_Workspace\\ILab_Selenium\\driver\\chromedriver.exe";
	   public WebDriver driver;
	   public String path;
	   
  @BeforeTest
  public void accessWebsite() {
	  try {
		  System.out.println("Launching Chrome browser"); 
	      System.setProperty("webdriver.chrome.driver", driverPath);
	      driver = new ChromeDriver();
	      driver.get(baseUrl);
	      driver.manage().window().maximize();	      
	      screenshot();
	         
	} catch (Exception e) {
		System.out.println("An error occured while trying to access the website: "+e.getMessage());
	}
	
      
  }
  
 @Test
  public void jobApplication() {
      try {
    	 
    	  String name = "Clara Mbuyisa";
    	  String email = " automationAssessment@iLABQuality.com";
    	  String randomNumbers = RandomStringUtils.randomNumeric(7);
    	  String phoneNo = "083"+randomNumbers;
    	  String expectedError = "You need to upload at least one file.";
    	  System.out.println(phoneNo);
    	  ExtentTest test = null;
    	  
    	  driver.findElement(By.xpath("//ul[@id='menu-primary-right-menu']//a[text()='CAREERS']")).click();
    	  //test.log(LogStatus.PASS, "Click on the careers link"+test.addScreenCapture(path));
    	  //test.log(LogStatus.PASS, "Careers link");
    	  screenshot();
    	  driver.findElement(By.xpath("//a[text()='South Africa']")).click();
    	  driver.findElement(By.xpath("//a[text()='Senior Test Automation Specialist � Johannesburg']")).click();
    	  driver.findElement(By.xpath("//a[@data-wpjb-form='wpjb-form-job-apply']")).click();
    	  driver.findElement(By.xpath("//input[@id='applicant_name']")).sendKeys(name);
    	  driver.findElement(By.xpath("//input[@id='email']")).sendKeys(email);
    	  driver.findElement(By.xpath("//input[@id='phone']")).sendKeys(phoneNo);
    	  Thread.sleep(2000);
    	  driver.findElement(By.xpath("//input[@id='wpjb_submit']")).click();
    	  Thread.sleep(1000);
    	  
    	  if(driver.findElement(By.xpath("//div[@class='wpjb-flash-error wpjb-flash-small']")).isDisplayed()) {
    		  String actualError = driver.findElement(By.xpath("//ul[@class='wpjb-errors']")).getText();
    		  if(expectedError.equalsIgnoreCase(actualError)) {
    			  System.out.println("Error message validation passed");
    		  }else {
    			  System.out.println("Error message validation failed");
    		  }
    		 
    	  }else {
    		  System.out.println("Application complete");
    	  }
    	  screenshot();
	} catch (Exception e) {
		System.out.println("An error occured: "+e.getMessage());
		
	}
	  
  }
 
 public void failTest() {
	 System.out.println("Test failed");
 }
 public void skipTest() {
	 System.out.println("Test skipped");
 }
  
@AfterClass
  public void close() {
	  if(driver!=null){
		  driver.close();
	  }
  }

public void screenshot() throws IOException {
	String userDir = System.getProperty("user.dir");
	String timeStamp;
	File screenShotName;
	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()); 
	screenShotName = new File(userDir+"\\Screenshots\\"+timeStamp+".png");
	FileUtils.copyFile(scrFile, screenShotName);

	String filePath = screenShotName.toString();
	path = "<img src=\"file://" + filePath + "\" alt=\"\"/>";
	Reporter.log(path);
}




}
