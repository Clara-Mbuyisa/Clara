package userListPackage;

import java.util.HashMap;
import java.util.Map;

public class Page_Objects extends WebsiteDriver {

	public Map<String, String> objects = new HashMap<String, String>();
	
	public void websiteObjects() {
		
		Map<String, String> objects = new HashMap<String, String>();
		
		objects.put("careerLink", "//ul[@id='menu-primary-right-menu']//a[text()='CAREERS']");
		objects.put("countryLink", "XPATH|//a[text()='South Africa']");
		objects.put("jobLink", "XPATH|//a[text()='Senior Test Automation Specialist – Johannesburg']");
		objects.put("applyLink", "XPATH|//a[@data-wpjb-form='wpjb-form-job-apply']");
		
		page_Objects = objects;
	}
}
