package userListPackage;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class NewTest {
	   public String baseUrl = "http://www.way2automation.com/angularjs-protractor/webtables/";
	   String driverPath = "C:\\Automation_Workspace\\Task2_UserList\\driver\\chromedriver.exe";
	   public WebDriver driver;
	   
  @BeforeTest
  public void VerifyUserListTable() {
	  try {
		  System.out.println("Launching Chrome browser"); 
	      System.setProperty("webdriver.chrome.driver", driverPath);
	      driver = new ChromeDriver();
	      driver.get(baseUrl);
	      driver.manage().window().maximize();
	      String expectedTitle = "Protractor practice website - WebTables";
	      String actualTitle = driver.getTitle();
	      System.out.println(actualTitle);
	      
	      //Verify that you are in the user list table
	      Assert.assertEquals(actualTitle, expectedTitle);
	      screenshot();
	      Reporter.log("WebTables page verified");
	      
	      
	    
	} catch (Exception e) {
		System.out.println("An error occured: "+e.getMessage());
	}
	
      
  }
  
  @Test
  @Parameters("firstName")
  public void AddUser() {
      try {
    	 
	      //Adding a user
	      String firstName = "FName";
          String lastName = "LName";
          String userName = "User";
          String password = "Pass";
          String email;
          String cell = "0839119090";
          
         
          
          for(int i=1; i<=2; i++) {
        	  
        	   driver.findElement(By.xpath("//button[@type='add']")).click();
        	   driver.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(firstName+i);
        	   driver.findElement(By.xpath("//input[@name='LastName']")).sendKeys(lastName+i);
        	   driver.findElement(By.xpath("//input[@name='UserName']")).sendKeys(userName+i);
        	   driver.findElement(By.xpath("//input[@name='Password']")).sendKeys(password+i);
        	   WebElement userRole = driver.findElement(By.xpath("//select[@name='RoleId']"));
               Select selc = new Select(userRole);
        	   if(i==1) {
        		   driver.findElement(By.xpath("//input[@value='15']")).click();
        		   selc.selectByVisibleText("Admin");
        		   email="admin@mail.com";
        		   driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(email);
        	   }else {
        		   driver.findElement(By.xpath("//input[@value='16']")).click();
        		   selc.selectByVisibleText("Customer");
        		   email="customer@mail.com";
        		   driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(email);
        	   }
       
        	   driver.findElement(By.xpath("//input[@name='Mobilephone']")).sendKeys(cell);
        	   Thread.sleep(2000);
        	   screenshot();
        	   driver.findElement(By.xpath("//button[text()='Save']")).click();
        	   Thread.sleep(5000);
        	   
        	   if(driver.findElement(By.xpath("//td[text()='" + firstName+i + "']")).isDisplayed()){
        		   System.out.println("User "+i+" added successfully");
        		   screenshot();
        		   driver.navigate().refresh();
        	   }else {
        		   System.out.println("Failed to add user");
        	   }
          }  
          
	} catch (Exception e) {
		System.out.println("An error occured: "+e.getMessage());
		
	}
	  
  }
  
@AfterClass
  public void close() {
	  if(driver!=null){
		  driver.close();
	  }
  }

public void screenshot() throws IOException {
	String userDir = System.getProperty("user.dir");
	String timeStamp;
	File screenShotName;
	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()); 
	screenShotName = new File(userDir+"\\Screenshots\\"+timeStamp+".png");
	FileUtils.copyFile(scrFile, screenShotName);

	String filePath = screenShotName.toString();
	String path = "<img src=\"file://" + filePath + "\" alt=\"\"/>";
	Reporter.log(path);
}



}
